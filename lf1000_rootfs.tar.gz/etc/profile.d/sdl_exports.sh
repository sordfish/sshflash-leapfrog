#!/bin/sh
# SDL exports
export SDL_NOMOUSE=1
export SDL_FBDEV="/dev/fb0"
export SDL_VIDEODRIVER="fbcon"
